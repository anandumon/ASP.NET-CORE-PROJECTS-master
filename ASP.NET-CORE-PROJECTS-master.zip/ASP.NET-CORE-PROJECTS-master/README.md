## Projects Build over Dotnet Core with MySQL

### Dotnet Core Tips and Tricks

[Link to Gist](https://gist.github.com/Somil112/9bd8c6d9f2637f000abd4ffe2cc90713)

### Carwale Test Page

[Link to Code](https://github.com/Somil112/ASP.NET-CORE-PROJECTS/tree/master/Carwale)

[Demo Video](https://github.com/Somil112/ASP.NET-CORE-PROJECTS/blob/master/Carwale/demo.mp4)
